<?php 

include('config.php');



$name = $_POST["name"];
$description = $_POST["description"];
$mrp = $_POST["mrp"];
$sp = $_POST["sp"];
$file = $_FILES['file']['name'];


$target_dir = "products/";
$target_name = $target_dir . basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'],$target_name);


$sql = "INSERT INTO `products` (`id`, `name`, `description`, `mrp`, `sp`, `image`) VALUES (NULL, '$name', '$description', '$mrp', '$sp', '$file');";

if (mysqli_query($conn,$sql)) {



     header("Location:productmanage.php");
} else {
    echo "Something went wrong". mysqli_error($conn);
}
mysqli_close($conn);





?>