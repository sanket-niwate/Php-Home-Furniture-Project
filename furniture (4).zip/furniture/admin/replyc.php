<?php
include('config.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'C:\xampp\htdocs\furniture\PHPMailer-master\src\Exception.php';
require 'C:\xampp\htdocs\furniture\PHPMailer-master\src\PHPMailer.php';
require 'C:\xampp\htdocs\furniture\PHPMailer-master\src\SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $adminReply = $_POST["reply"];
    $userEmail = $_POST["email"];

    // Save admin reply to the admin_replies table
    $insertReplySQL = "INSERT INTO admin_repliesc (user_email, admin_reply) VALUES ('$userEmail', '$adminReply')";
    mysqli_query($conn, $insertReplySQL);

    // Send email notification to the user
    $uemail = 'sanketnivate2k18@gmail.com';
    $password = 'iali rmxa faqy xrsa';

    $mail = new PHPMailer(true);

    try {
        // Configure SMTP settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = $uemail;
        $mail->Password = $password;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 25;

        // Recipient information
        $mail->setFrom($uemail, 'Home Furniture');
        $mail->addAddress($userEmail);
        $mail->addReplyTo($uemail, 'Home Furniture');

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'Admin Reply';
        $mail->Body = $adminReply;

        $mail->send();
        echo '<!DOCTYPE html>
        <html lang="en">
        
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Email Sent</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 0;
                    padding: 0;
                    background-color: #f4f4f4;
                    text-align: center;
                }
        
                .success-message {
                    background-color: #2f4858;
                    color: white;
                    padding: 20px;
                    margin: 20% auto;
                    max-width: 400px;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                }
        
                .back-button {
                    background-color:  rgb(255, 123, 0);
                    color: white;
                    padding: 10px 20px;
                    text-decoration: none;
                    border-radius: 5px;
                    margin-top: 20px;
                    display: inline-block;
                }
        
                @media only screen and (max-width: 600px) {
                    .success-message {
                        margin: 10% auto;
                    }
                }
            </style>
        </head>
        
        <body>
        
            <div class="success-message">
                <h2>Email sent successfully</h2>
                <a href="javascript:history.back()" class="back-button">Back</a>
            </div>
        
        </body>
        
        </html>
        ';
    } catch (Exception $e) {
        echo 'Failed to send email: ', $mail->ErrorInfo;
    }
}

mysqli_close($conn);
?>