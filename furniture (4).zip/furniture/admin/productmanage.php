<!DOCTYPE html>
<html lang="en">

<head>
    <title>Product List</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.3.2 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="demo.css">
    <link rel="shortcut icon" href="Images/images (1).png" type="image/x-icon">
    <link rel="stylesheet" href="testimo.css">
    <style>
    .navbar-nav {
        margin-left: auto;
    }

    .center {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 90%;
    }

    h1 {
        display: block;
        font-size: 1.5em;
        margin-top: 0.83em;
        margin-bottom: 0.83em;
        margin-left: 0%;
        margin-right: 0%;
        font-weight: bold;
        text-align: center;
    }

    .login-container {
        max-width: 400px;
        padding: 20px;
        border: 1px solid #ccc;
        background-color: #fff;
    }

    form {
        text-align: left;
    }

    .form {
        text-align: right;
    }

    .form-group {
        margin-bottom: 15px;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }

    .input {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    button {
        background-color: #ff5100;
        color: #fff;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
    }

    .a-login {
        text-decoration: none;
        padding: 14p 25px;
        text-align: justify;
        display: inline-block;
        font-size: 16px;
        color: black;
    }

    .button:hover {
        background-color: #ff510079;
    }

    .center {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 90%;
    }

    h1 {
        display: block;
        font-size: 1.5em;
        margin-top: 0.83em;
        margin-bottom: 0.83em;
        margin-left: 0%;
        margin-right: 0%;
        font-weight: bold;
        text-align: center;
    }

    footer {
        background-color: #333;
        color: #fff;
    }

    .btn-bd-primary {
        --bd-violet-bg: #f7b51b;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #f7b51b;
        --bs-btn-hover-border-color: #f7b51b;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #f7b51b;
        --bs-btn-active-border-color: #f7b51b;
    }

    .imgage-login {
        width: 17px;
        height: 17px;
        float: left;
    }

    textarea {
        float: left;
        width: 370px;
    }

    .form-container {
        display: flex;
        flex-direction: column;
        width: 100%;
        max-width: 700px;
        background-color: #f2f2f2;
        border: 1px solid #ddd;
        border-radius: 8px;
        overflow: hidden;
    }

    .image-section {
        background-color: #2f4858;
        text-align: center;
        padding: 20px;
        color: #fff;
    }

    .content-section {
        padding: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .img-login {
        max-width: 100%;
        max-height: 100%;
        border-radius: 8px;
    }

    .input {
        width: 100%;
        padding: 10px;
        box-sizing: border-box;
    }

    .a-login,
    .registration-button {
        background-color: rgb(255, 123, 0);
        color: #fff;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
        text-decoration: none;
    }

    button {
        background-color: rgb(255, 123, 0);
        color: #fff;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
    }

    p {
        margin: 0;
    }

    .a-login,
    .registration-link {
        color: rgb(0, 0, 0);
        text-decoration: none;
    }

    /* Media Query for Tablets and larger screens */
    @media (min-width: 768px) {
        .form-container {
            flex-direction: row;
        }

        .image-section {
            flex: 1;
        }

        .content-section {
            flex: 1;
        }
    }

    .img {
        max-width: 100%;
        height: auto;
        display: block;
        margin: 0 auto;
        border-radius: 10px;
        /* Example: Add a border-radius */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        /* Example: Add a box shadow */
        /* Add any other custom styles you want */
    }
    </style>
</head>

<body>
    <header class="sticky-top bg-white">
        <p class="py-2 text-center" style="background-color: #ffd166"> <span class="fs-4" style="
                        color:#2f4858;
                        font-weight: bold;
                        text-transform: uppercase;
                        letter-spacing: 2px;
                        font-family: Arial, sans-serif;
                    ">A d m i n
            </span></p>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img class="img-fluid pe-2" width="50" height="50" src="Images/images%20(1).png" alt="images%20(1)">
                    <span class="fs-4"
                        style="color: #2f4858; font-weight: bold; text-transform: uppercase; letter-spacing: 2px; font-family: Arial, sans-serif;">Home</span>
                    &nbsp;&nbsp; <span class="fs-4"
                        style="color: rgb(255, 123, 0); font-weight: bold; text-transform: uppercase; letter-spacing: 2px; font-family: Arial, sans-serif;">Furniture</span>


                </a>

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavId"
                    aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="iadmin.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="usermanage.php">Usermanage</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">Addproducts</a>
                            <div class="dropdown-menu px-2" aria-labelledby="dropdownId">
                                <!-- Add your dropdown items here -->
                                <a class="dropdown-item" href="#"><b>Chair</b></a>
                                <a class="nav-link pt-0 active" href="Addproduct.html">AddChairs</a> <a
                                    class="nav-link pb-1" href="productmanage.php">ManageChairs</a>
                                <hr><br>
                                <a class="dropdown-item" href="#"><b>Sofa</b></a>
                                <a class="nav-link pt-0 active" href="addproductsofa.html">AddSofas</a> <a
                                    class="nav-link pb-1" href="productmanagesofa.php">ManageSofas</a>
                                <hr><br>
                                <a class="dropdown-item" href="#"><b>Table</b></a>
                                <a class="nav-link pt-0 active" href="addproducttable.html">AddTables</a> <a
                                    class="nav-link pb-1" href="productmanagetable.php">ManageTables</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="retrieve_data.php">Users Queary</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="display_data.php">Orders</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main class="container">

        <?php
    include('config.php');

    $sql = "SELECT * FROM `products`";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
      echo "<div class='table-responsive'>
      <h2 class='text-center mb-4 pt-5'>Chairs</h2>
            <table class='table table-bordered table-striped'>
                <thead class='table-primary'>
                    <tr>
                        <th scope='col'>Id</th>
                        <th scope='col'>Name</th>
                        <th scope='col'>Description</th>
                        <th scope='col'>MRP</th>
                        <th scope='col'>Offer Price</th>
                        <th scope='col'>Image</th>
                        <th scope='col'>Action</th>
                    </tr>
                </thead>
                <tbody>";

      while ($rows = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td scope='row'>{$rows['id']}</td>
                <td>{$rows['name']}</td>
                <td>{$rows['description']}</td>
                <td>{$rows['mrp']}</td>
                <td>{$rows['sp']}</td>
                <td><img src='products/{$rows['image']}' class='img-fluid img'></td>
                <td>
                    <a class='btn btn-warning btn-action' href='editproduct.php?id={$rows['id']}' role='button'>Edit</a>
                    <a class='btn btn-danger btn-action' href='deletep.php?id={$rows['id']}' role='button'>Delete</a>
                </td>
              </tr>";
      }

      echo "</tbody>
          </table>
        </div>";
    } else {
      echo "<p class='alert alert-info'>0 records found</p>";
    }

    mysqli_close($conn);
    ?>

    </main>
    <footer>
        <!-- Footer content can be added here -->
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>