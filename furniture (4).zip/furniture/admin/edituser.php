<?php 

include('config.php');

$id = $_GET["id"];

$sql = "SELECT * FROM `users` WHERE `id` = $id";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);


mysqli_close($conn);



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="demo.css">
    <link rel="shortcut icon" href="Images/images (1).png" type="image/x-icon">
    <link rel="stylesheet" href="testimo.css">
    <title>Update Form</title>
    <style>
    body {
        background-color: rgb(255, 123, 0);
        color: #fff;
        /* Set text color to white for better readability */
    }

    .container {
        max-width: 800px;
        margin-top: 50px;
        background-color: #2f4858;
        border-radius: 10px;
    }

    .image-section {
        text-align: center;
        padding: 20px;

    }

    .form-section {
        padding: 20px;
    }
    </style>
</head>

<body>

    <div class="container">
        <div class="row">
            <!-- Image Section -->
            <div class="col-md-6 image-section">
                <img src="Images/ll.jpg" alt="Image" class="img-fluid mt-5">
            </div>

            <!-- Form Section -->
            <div class="col-md-6 form-section">
                <h2 class="mb-4">Update Form</h2>
                <form action="update.php" method="post">
                    <div class="mb-3">
                        <input type="hidden" class="form-control" name="id" value='<?php echo "{$row['id']}";?>'>
                    </div>

                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Enter Name"
                            value='<?php echo "{$row['name']}";?>'>
                        <small class="form-text text-muted">Enter your full name</small>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="abc@mail.com"
                            value='<?php echo "{$row['email']}";?>'>
                        <small class="form-text text-muted">Enter your email address</small>
                    </div>

                    <div class="mb-3">
                        <label for="uname" class="form-label">Username</label>
                        <input type="text" class="form-control" name="uname" id="uname" placeholder="Enter Username"
                            value='<?php echo "{$row['username']}";?>'>
                        <small class="form-text text-muted">Choose a unique username</small>
                    </div>

                    <div class="mb-3">
                        <label for="pass" class="form-label">Password</label>
                        <input type="password" class="form-control" name="pass" id="pass" placeholder="Enter Password"
                            value='<?php echo "{$row['password']}";?>'>
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>

</body>

</html>