<?php 
include('config.php');


$id = $_GET["id"];

$sql = "DELETE FROM `products` WHERE `products`.`id` = $id";

if (mysqli_query($conn,$sql)) {
     header("Location:productmanagesofa.php");
} else {
    echo "Something went wrong". mysqli_error($conn);
}
mysqli_close($conn);



?>