<?php
include('config.php');

// Check if product ID is set in the URL
if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    // Fetch product details
    $sql = "SELECT * FROM `products` WHERE id = $productId";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $productName = $row['name'];
        $productDescription = $row['description'];
        $productMRP = $row['mrp'];
        $productSP = $row['sp'];
        $productImage = $row['image'];
    } else {
        echo "<p class='alert alert-danger'>Product not found</p>";
        exit(); // Stop execution if product not found
    }
} else {
    echo "<p class='alert alert-danger'>Invalid product ID</p>";
    exit(); // Stop execution if product ID is not set
}

// Handle form submission for updating product details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve updated values from the form
    $updatedName = mysqli_real_escape_string($conn, $_POST['name']);
    $updatedDescription = mysqli_real_escape_string($conn, $_POST['description']);
    $updatedMRP = $_POST['mrp'];
    $updatedSP = $_POST['sp'];

    // Check if a new image is uploaded
    if ($_FILES['image']['name']) {
        $uploadedImage = $_FILES['image'];
        $imageName = $uploadedImage['name'];
        $imageTmpName = $uploadedImage['tmp_name'];
        $imageSize = $uploadedImage['size'];
        $imageError = $uploadedImage['error'];

        // Move the uploaded image to the 'products' directory
        move_uploaded_file($imageTmpName, "products/$imageName");

        // Update the product details with the new image
        $updateSql = "UPDATE `products` SET 
                      name = '$updatedName', 
                      description = '$updatedDescription', 
                      mrp = '$updatedMRP', 
                      sp = '$updatedSP', 
                      image = '$imageName' 
                      WHERE id = $productId";
    } else {
        // Update the product details without changing the image
        $updateSql = "UPDATE `products` SET 
                      name = '$updatedName', 
                      description = '$updatedDescription', 
                      mrp = '$updatedMRP', 
                      sp = '$updatedSP' 
                      WHERE id = $productId";
    }

    if (mysqli_query($conn, $updateSql)) {
        echo "<p class='alert alert-success'>Product details updated successfully</p>";
    } else {
        echo "<p class='alert alert-danger'>Error updating product details: " . mysqli_error($conn) . "</p>";
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous" />
    <link rel="stylesheet" href="demo.css" />
    <link rel="shortcut icon" href="Images/images (1).png" type="image/x-icon" />
    <style>
    .navbar-nav {
        margin-left: auto;
    }

    .center {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 90%;
    }

    h1 {
        display: block;
        font-size: 1.5em;
        margin-top: 0.83em;
        margin-bottom: 0.83em;
        margin-left: 0%;
        margin-right: 0%;
        font-weight: bold;
        text-align: center;
    }

    .login-container {
        max-width: 400px;
        padding: 20px;
        border: 1px solid #ccc;
        background-color: #fff;
    }

    form {
        text-align: left;
    }

    .form {
        text-align: right;
    }

    .form-group {
        margin-bottom: 15px;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }

    .input {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    button {
        background-color: #ff5100;
        color: #fff;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
    }

    .a-login {
        text-decoration: none;
        padding: 14p 25px;
        text-align: justify;
        display: inline-block;
        font-size: 16px;
        color: black;
    }

    .button:hover {
        background-color: #ff510079;
    }

    .center {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 90%;
    }

    h1 {
        display: block;
        font-size: 1.5em;
        margin-top: 0.83em;
        margin-bottom: 0.83em;
        margin-left: 0%;
        margin-right: 0%;
        font-weight: bold;
        text-align: center;
    }

    footer {
        background-color: #333;
        color: #fff;
    }

    .btn-bd-primary {
        --bd-violet-bg: #f7b51b;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #f7b51b;
        --bs-btn-hover-border-color: #f7b51b;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #f7b51b;
        --bs-btn-active-border-color: #f7b51b;
    }

    .imgage-login {
        width: 17px;
        height: 17px;
        float: left;
    }

    textarea {
        float: left;
        width: 370px;
    }

    .form-container {
        display: flex;
        flex-direction: column;
        width: 100%;
        max-width: 700px;
        background-color: #f2f2f2;
        border: 1px solid #ddd;
        border-radius: 8px;
        overflow: hidden;
    }

    .image-section {
        background-color: #2f4858;
        text-align: center;
        padding: 20px;
        color: #fff;
    }

    .content-section {
        padding: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .img-login {
        max-width: 100%;
        max-height: 100%;
        border-radius: 8px;
    }

    .input {
        width: 100%;
        padding: 10px;
        box-sizing: border-box;
    }

    .a-login,
    .registration-button {
        background-color: rgb(255, 123, 0);
        color: #fff;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
        text-decoration: none;
    }

    button {
        background-color: rgb(255, 123, 0);
        color: #fff;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
    }

    p {
        margin: 0;
    }

    .a-login,
    .registration-link {
        color: rgb(0, 0, 0);
        text-decoration: none;
    }

    /* Media Query for Tablets and larger screens */
    @media (min-width: 768px) {
        .form-container {
            flex-direction: row;
        }

        .image-section {
            flex: 1;
        }

        .content-section {
            flex: 1;
        }
    }

    .back-button {
        background-color: rgb(255, 123, 0);
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
        margin-top: 20px;
        display: inline-block;
    }
    </style>
</head>

<body>
    <center>
        <div class="form-container mt-5">

            <form method="post" action="" enctype="multipart/form-data" class="center p-3">
                <div class="mb-3">
                    <label for="name" class="form-label">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo $productName; ?>"
                        required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description:</label>
                    <textarea class="form-control" id="description" name="description"
                        required><?php echo $productDescription; ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="mrp" class="form-label">MRP:</label>
                    <input type="text" class="form-control" id="mrp" name="mrp" value="<?php echo $productMRP; ?>"
                        required>
                </div>
                <div class="mb-3">
                    <label for="sp" class="form-label">Offer Price:</label>
                    <input type="text" class="form-control" id="sp" name="sp" value="<?php echo $productSP; ?>"
                        required>
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Image:</label>
                    <div class="input-group"> <input type="file" class=" form-control-file" id="image" name="image"
                            onchange="displayImage(this)">
                    </div>
                </div>
                <div class="mt-2">
                    <img id="selectedImage" class="img-fluid rounded" alt="Selected Image"
                        style="max-width: 300px; display: none" />
                    <p id="imageSizeText" class="mt-2 text-muted"></p>
                </div>
                <button type="submit" class="login-button center mt-3"
                    style="padding-left: 100px ;padding-right: 100px;">Update
                    Product</button>
                <center><a href="javascript:history.back()" class="back-button">Back</a></center>
        </div>



        </form>
        </div>
    </center>

    <!-- Bootstrap JS (optional, if you need it) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function displayImage(input) {
        var selectedImage = document.getElementById("selectedImage");
        var imageSizeText = document.getElementById("imageSizeText");

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                selectedImage.src = e.target.result;
                selectedImage.style.display = "block";

                // Display image size information
                imageSizeText.innerText =
                    "Image Size: " + input.files[0].size / 1024 + " KB";
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>

</body>

</html>