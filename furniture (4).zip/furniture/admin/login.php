<?php 

session_start();

include('config.php');

$uname=$_POST["uname"];
$pass=$_POST["pass"];



$sql = "SELECT * FROM `admin` WHERE `name`='$uname' AND `password`='$pass'";
$result = mysqli_query($conn,$sql);



if (mysqli_num_rows($result)>0) {
  $_SESSION["uname"] = $uname;
  $_SESSION["pass"] = $pass;
  header("Location:iadmin.php");
} else {
  header("Location:error.html");
}
mysqli_close($conn);



?>