<?php 

include('config.php');
$id=$_POST["id"];
$name=$_POST["name"];
$description=$_POST["description"];
$mrp=$_POST["mrp"];
$sp=$_POST["sp"];



$sql = "UPDATE `products` SET `name`='$name',`description`='$description',`mrp`='$mrp',`sp`='$sp' WHERE `products`.`id` = $id;";

if (mysqli_query($conn,$sql)) {
    header("Location:productmanage.php");
} else {
    echo "Something went wrong". mysqli_error($conn);
}
mysqli_close($conn);



?>