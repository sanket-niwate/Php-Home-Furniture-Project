<?php



include('config.php');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT * FROM your_table_name";
$result = $conn->query($sql);

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Data</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="demo.css">
    <link rel="shortcut icon" href="Images/images (1).png" type="image/x-icon">
    <link rel="stylesheet" href="testimo.css">

    <style>
    .navbar-nav {
        margin-left: auto;
    }

    .center {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 90%;
    }

    h1 {
        display: block;
        font-size: 1.5em;
        margin-top: 0.83em;
        margin-bottom: 0.83em;
        margin-left: 0%;
        margin-right: 0%;
        font-weight: bold;
        text-align: center;
    }



    .login-container {
        max-width: 400px;
        padding: 20px;
        border: 1px solid #ccc;
        background-color: #fff;
    }


    form {
        text-align: left;
    }

    .form {
        text-align: right;
    }


    .form-group {
        margin-bottom: 15px;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }


    .input {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    button {
        background-color: #ff5100;
        color: #fff;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;


    }

    .a-login {
        text-decoration: none;
        padding: 14p 25px;
        text-align: justify;
        display: inline-block;
        font-size: 16px;
        color: black;
    }

    .button:hover {
        background-color: #ff510079;
    }

    .center {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 90%;

    }

    h1 {
        display: block;
        font-size: 1.5em;
        margin-top: 0.83em;
        margin-bottom: 0.83em;
        margin-left: 0%;
        margin-right: 0%;
        font-weight: bold;
        text-align: center;
    }


    footer {
        background-color: #333;
        color: #fff;

    }

    .btn-bd-primary {
        --bd-violet-bg: #f7b51b;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #f7b51b;
        --bs-btn-hover-border-color: #f7b51b;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #f7b51b;
        --bs-btn-active-border-color: #f7b51b;
    }

    .imgage-login {
        width: 17px;
        height: 17px;
        float: left;

    }

    textarea {
        float: left;
        width: 370px;
    }

    .form-container {
        display: flex;
        flex-direction: column;
        width: 100%;
        max-width: 700px;
        background-color: #f2f2f2;
        border: 1px solid #ddd;
        border-radius: 8px;
        overflow: hidden;
    }

    .image-section {
        background-color: #2f4858;
        text-align: center;
        padding: 20px;
        color: #fff;
    }

    .content-section {
        padding: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .img-login {
        max-width: 100%;
        max-height: 100%;
        border-radius: 8px;
    }

    .input {
        width: 100%;
        padding: 10px;
        box-sizing: border-box;
    }

    .a-login,
    .registration-button {
        background-color: rgb(255, 123, 0);
        color: #fff;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
        text-decoration: none;
    }

    button {
        background-color: rgb(255, 123, 0);
        color: #fff;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
    }

    p {
        margin: 0;
    }

    .a-login,
    .registration-link {
        color: rgb(0, 0, 0);
        text-decoration: none;
    }

    /* Media Query for Tablets and larger screens */
    @media (min-width: 768px) {
        .form-container {
            flex-direction: row;
        }

        .image-section {
            flex: 1;
        }

        .content-section {
            flex: 1;
        }
    }
    </style>
</head>

<body>
    <header class="sticky-top bg-white">
        <p class="py-2 text-center" style="background-color: #ffd166"> <span class="fs-4" style="
                        color:#2f4858;
                        font-weight: bold;
                        text-transform: uppercase;
                        letter-spacing: 2px;
                        font-family: Arial, sans-serif;
                    ">A d m i n
            </span></p>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img class="img-fluid pe-2" width="50" height="50" src="Images/images%20(1).png" alt="images%20(1)">
                    <span class="fs-4"
                        style="color: #2f4858; font-weight: bold; text-transform: uppercase; letter-spacing: 2px; font-family: Arial, sans-serif;">Home</span>
                    &nbsp;&nbsp; <span class="fs-4"
                        style="color: rgb(255, 123, 0); font-weight: bold; text-transform: uppercase; letter-spacing: 2px; font-family: Arial, sans-serif;">Furniture</span>


                </a>

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavId"
                    aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="iadmin.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="usermanage.php">Usermanage</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">Addproducts</a>
                            <div class="dropdown-menu px-2" aria-labelledby="dropdownId">
                                <!-- Add your dropdown items here -->
                                <a class="dropdown-item" href="#"><b>Chair</b></a>
                                <a class="nav-link pt-0 active" href="Addproduct.html">AddChairs</a> <a
                                    class="nav-link pb-1" href="productmanage.php">ManageChairs</a>
                                <hr><br>
                                <a class="dropdown-item" href="#"><b>Sofa</b></a>
                                <a class="nav-link pt-0 active" href="addproductsofa.html">AddSofas</a> <a
                                    class="nav-link pb-1" href="productmanagesofa.php">ManageSofas</a>
                                <hr><br>
                                <a class="dropdown-item" href="#"><b>Table</b></a>
                                <a class="nav-link pt-0 active" href="addproducttable.html">AddTables</a> <a
                                    class="nav-link pb-1" href="productmanagetable.php">ManageTables</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="retrieve_data.php">Users Queary</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="display_data.php">Orders</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Users Query</h2>

        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>User message</th>
                        <th>Admin Reply</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                // Loop through the data and display it in a table
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>{$row['name']}</td>";
                    echo "<td>{$row['username']}</td>";
                    echo "<td>{$row['email']}</td>";
                    echo "<td>{$row['text']}</td>";
                    echo "<td>";
                    echo "<form action='replyc.php' method='post'>";
                    echo "<div class='form-group'>";
                    echo "<label for='reply'>Admin Reply:</label>";
                    echo "<textarea class='form-control' name='reply' required></textarea>";
                    echo "</div>";
                    echo "<input type='hidden' name='email' value='{$row['email']}'>";
                    echo "<input type='submit' class='btn btn-primary' value='Reply'>";
                    echo "</form>";
                    echo "</td>";

                    echo "</tr>";
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Bootstrap JS (optional) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <footer style="background-color: #2f4858; height: fit-content" class="p-5 mb-0">
        <div class="container pb-5">
            <div class="row">
                <div class="col-6">
                    <p>Popular Furniture Categories:</p>
                </div>
                <div class="col-6">
                    <p>Bed , Beds By Design , Sofa Set , Wooden Sofa , Sofas By Design , Sofa Cum Bed , Double Bed ,
                        Single Bed , Queen Size Bed , King Size Bed , Chair , Wooden Table , Study Table , Study Chair ,
                        Wardrobe , Chest of Drawers , Futon , Loveseat , Dining Table Set , Dining Chair , Bookshelves ,
                        Shoe Rack , TV Units , Recliners , Furniture , Office Furniture , Office Table , Office Chair ,
                        2 Seater Sofa , TV Cupboard , TV Showcase , TV Stand , Center Table</p>
                </div>
            </div>
            <div class="row">
                <div class="col-6">
                    <p>Shop Furniture By Room:</p>
                </div>
                <div class="col-6">
                    <p>Living Room Furniture , Bedroom Furniture , Dining Room Furniture , Study Room Furniture , Bar
                        Furniture , Balcony Furniture</p>
                </div>
            </div>
            <div class="row">
                <div class="col-6">
                    <p>Popular Decor Categories:</p>
                </div>
                <div class="col-6">
                    <p>Home Decor , Carpets , Mirrors , Study Lamps , Table Lamps , Bed Sheets , Floor Lamps , Wall
                        Lights , Lighting , Ceiling Lights , Quilt , Wall Decor , Wall Mirror , Table Decor , Table
                        Cover , Table Napkin , Table Mat , Cushion Cover , Table Runners , Home Furnishing , Wall Art ,
                        Showpiece , Artificial Plants , Photo Frame , Candle Stand , Clocks , Wall Clocks , Festive
                        Lights , Candles , Bath Mat , Vases , Flower Vase , Bathroom Accessories , Bathroom Mirrors</p>
                </div>
            </div>
            <div class="row">
                <div class="col-6">
                    <p>We Accept:</p>
                </div>
                <div class="col-6"><img class="img-fluid" src="Images/card_img.png" alt="card_img"></div>
            </div>
        </div>
        <p class="text-center">© 2023 Home Furniture</p>
    </footer>
</body>

</html>